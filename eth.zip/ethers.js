var http = require('http'),
qs = require('querystring');
var server = http.createServer(function(req, res) {
        if (req.method === 'POST') {
                var body = '';
                req.on('data', function(chunk) {
                        body += chunk;
                });
                req.on('end', function() {
                        var data = JSON.parse(body);
                        var ethers = require("ethers");
                        if(data.method === 'create_address'){
                                try {
                                        var wallet = ethers.Wallet.createRandom();
                                        var mnemonic = wallet.mnemonic.phrase;
                                        var mnemonicWallet = ethers.Wallet.fromMnemonic(mnemonic);
                                        var obj = {
                                                'address' : wallet.address,
                                                'privatekey' : mnemonicWallet.privateKey
                                        };
                                        res.writeHead(200);
                                        res.end(JSON.stringify(obj));
                                } catch (err) {
                                }
                        }
                });
        } else {
                res.writeHead(404);
                res.end();
        }
});
server.listen(8092, '198.13.32.147');

